Usage: 

PhoneChess 
  - With no arguments:
      Runs self-tests on piece moves and then runs solution to
        Queen starting at key "5", length 10 

Or:

PhoneChess <piece> <start digit> [<length> <show moves>]
  Where:
    Piece [Pawn|King|Queen|Rook|Kight|Bishop]
    start digit [0-9]
    length [1-10]
    showm moves [true|false]

