# should build under Scala 2.7.7 or 2.8beta1
scalac PhoneChess.scala
