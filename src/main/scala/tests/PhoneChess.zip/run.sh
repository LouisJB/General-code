scala tests.PhoneChess $1 $2 $3 $4

